export default class DbWork {
    constructor(fileName = 'db.json') {
        this.fileName = fileName;
    }

    async readFile(fileName = this.fileName) {
        const file = await fetch(fileName);
        if (!file.ok) throw new Error(`Error. File ${fileName} does not exist`);
        return await file.json();
    }

    async getBestsellers() {
        const file = await this.readFile();
        return file.bestsellers;
    }
    
    async getCoffee() {
        const file = await this.readFile();
        return file.coffee;
    }

    async getGoods() {
        const file = await this.readFile();
        return file.goods;
    }

}