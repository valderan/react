import React from 'react';
import DbWork from '../../services/dbWork';
import { Card, CardBody, CardTitle, CardText, CardImg } from 'reactstrap';
import { Container, Row, Col } from 'reactstrap';


export default class App extends React.Component {
  constructor(props) {
    super(props);
    
    this.state = {
      bestsellers: [],
      coffee: [],
      goods: []

    }

    this.getAll();
  }

  getAll = async () => {
    const db = new DbWork();
    const bestsellers = await db.getBestsellers();
    const coffee = await db.getCoffee();
    const goods = await db.getGoods()
    this.setState({bestsellers, coffee, goods})
    
  } 

  render() {

    const { bestsellers, coffee, goods } = this.state;
    
    const bestsellers_ = [];
    const coffee_ = [];
    const goods_ = [];

    if (bestsellers.length > 0) {
      bestsellers.forEach( element => {
        bestsellers_.push(
          
          <Card>
            <CardImg top width="20%" src={element.url} alt="bestseller" />
            <CardBody>
              <CardTitle>Price {element.price}</CardTitle>
              <CardText>{element.name}</CardText>
            </CardBody>
          </Card>
        
        )
      })
    }

    if (coffee.length > 0) {
      coffee.forEach( element => {
        coffee_.push(
          
          <Card>
            <CardImg top width="20%" src={element.url} alt="cofee" />
            <CardBody>
              <CardTitle>{element.name}</CardTitle>
              <CardTitle>Price {element.price}</CardTitle>
              <CardText>{element.description}</CardText>
              <CardText>
                <small className="text-muted">country: {element.country}</small>
              </CardText>
            </CardBody>
          </Card>
        
        )
      })
    }

    if (goods.length > 0) {
      goods.forEach( element => {
        goods_.push(
          
          <Card>
            <CardImg top width="20%" height="20%" src={element.url} alt="goods" />
            <CardBody>
              <CardTitle>Price {element.price}</CardTitle>
              <CardText>{element.name}</CardText>
            </CardBody>
          </Card>
        
        )
      })
    }

    return (
      <div className="App">
        <Container>
        <Row>
            <Col xs="6" sm="4">Bestsellers</Col>
            <Col xs="6" sm="4">Cofee</Col>
            <Col sm="4">Goods</Col>
          </Row>
          <Row>
            <Col xs="6" sm="4">{bestsellers_}</Col>
            <Col xs="6" sm="4">{coffee_}</Col>
            <Col sm="4">{goods_}</Col>
          </Row>
         </Container>
      </div>
    );
  }
}

